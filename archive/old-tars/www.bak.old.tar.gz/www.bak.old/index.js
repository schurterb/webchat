window.onload=start;


function start() {
    webchatUtilities.initialize();
    webchatStartpage.initialize();
}