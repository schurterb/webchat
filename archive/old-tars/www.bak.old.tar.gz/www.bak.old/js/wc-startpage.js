var webchatStartpage = {
    initialize: function() {
        var contents = "";
        contents += "<div id=\"start-chat\" class=\"center\">";
        contents += "<h3 class=\"text-center\">JOIN OR START A CHAT:</h3>";
        
        contents += "<div class=\"btn-group\">";
        contents += "<a class=\"btn btn-primary btn-custom\" href=\"#\" onclick=\"javascript:webchatUtilities.startchat()\">Start Chat</a>";
        contents += "<a class=\"btn btn-primary btn-custom\" href=\"#\" onclick=\"javascript:webchatUtilities.joinchat()\">Join Chat</a>";
        contents += "</div>";
        
        contents += "</div>";
        
        document.getElementById('main-center').innerHTML = contents;
    }
}