/*global atob*/
/*global btoa*/
var utilities = {
    
    getCookie: function(name) {
      var cookies = document.cookie.split(";");
      for( var i=0; i<cookies.length; i++) {
        if(cookies[i].split("=")[0].trim() == name) {
          try {
            return JSON.parse(atob(cookies[i].split("=")[1]));
          } catch(e) {
            return cookies[i].split("=")[1];
          }
        }
      }
    },
    
    setCookie: function(name, value, encode=true) {
        if(encode) {
            value = btoa(JSON.stringify(value));
        }
        document.cookie = name + '=' + value + ';';
    }
}