/*
 *  Copyright (c) 2014 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree.
 */

/* More information about these options at jshint.com/docs/options */

/* globals parseJSON, trace, webchatServerless */
/* exported ServerlessSignalingChannel */

'use strict';

// This class implements a signaling channel based on WebSocket.
var ServerlessSignalingChannel = function(wssUrl, wssPostUrl) {
  this.wssUrl_ = wssUrl;
  this.wssPostUrl_ = wssPostUrl;
  this.roomId_ = null;
  this.clientId_ = null;
  this.knownPeers_ = [];
  this.registered_ = false;

  // Public callbacks. Keep it sorted.
  this.onerror = null;
  this.onmessage = null;
  
  this.message_in_progress = false;
  this.message_queue = [];
};

ServerlessSignalingChannel.prototype.checkReceivedMessages = 

ServerlessSignalingChannel.prototype.open = function() {
  if (this.registered_) {
    trace('ERROR: ServerlessSignalingChannel has already opened.');
    return;
  }

  trace('Opening signaling channel.');
  if (this.clientId_ && this.roomId_) {
    this.register(this.roomId_, this.clientId_);
  }
};

ServerlessSignalingChannel.prototype.register = async function(roomId, clientId) {
  if (this.registered_) {
    trace('ERROR: ServerlessSignalingChannel has already registered.');
    return;
  }

  this.roomId_ = roomId;
  this.clientId_ = clientId;

  if (!this.roomId_) {
    trace('ERROR: missing roomId.');
  }
  if (!this.clientId_) {
    trace('ERROR: missing clientId.');
  }
  trace('Registering signaling channel.');
  this.connectionFile_ = this.clientId_;
  var output = await webchatServerless.createFile(this.connectionFile_, "[]");
  this.registered_ = true; //TODO: Verify that we can write to the file place...
  trace('Signaling channel registered.');
  
  trace('Starting listener');
  var interval_id = setInterval(async function() {
    if (this.registered_ && !this.message_in_progress) {
      this.message_in_progress = true;
      
      var files = await webchatServerless.listFiles();
      for(var i=0; i<files.length; i++) {
        if(files[i] != this.clientId_ && (this.knownPeers_.indexOf(files[i]) == -1)) {
          
          console.log("Found new peer: "+files[i]);
          var contents = await webchatServerless.getFile(files[i]);
          var messages = JSON.parse(contents.Body);
          
          messages.forEach(function (message) {
            trace('SSC->C: ' + message);
            this.onmessage(message);
          }.bind(this));
          
          this.knownPeers_.push(files[i]);
        }
      }
      
      this.message_in_progress = false;
    }
  }.bind(this), 10000, 10000);
};

ServerlessSignalingChannel.prototype.close = async function(async) {
  if (!this.clientId_ || !this.roomId_) {
    return;
  }
  
  var output = await webchatServerless.deleteFile(this.connectionFile_);
  this.connectionFile_ = null;
};

ServerlessSignalingChannel.prototype.send = function(message) {
  if (!this.roomId_ || !this.clientId_) {
    trace('ERROR: ServerlessSignalingChannel has not registered.');
    return;
  }
  
  var message_id = webchatTools.randomString(20);
  this.message_queue.push(message_id);
  
  console.log("Message queued up with id : "+message_id);
  
  var interval_id = setInterval(async function() {
    if( this.registered_ && (this.message_queue[0] == message_id) && !this.message_in_progress ) {
      this.message_in_progress = true;
      var contents = await webchatServerless.getFile(this.connectionFile_);
      var data = JSON.parse(contents.Body);
      data.push(message);
      var msgString = JSON.stringify(data);
      var output = await webchatServerless.updateFile(this.connectionFile_, msgString);
      
      console.log('C->SSC: Sent '+message_id);
      clearInterval(interval_id);
      this.message_queue.shift();
      this.message_in_progress = false;
    }
  }.bind(this), 1000);
};
