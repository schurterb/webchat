var webchatTools = {
    
    randomString: function(length, chars='aA#') {
        var mask = '';
        if (chars.indexOf('a') > -1) mask += 'abcdefghijklmnopqrstuvwxyz';
        if (chars.indexOf('A') > -1) mask += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        if (chars.indexOf('#') > -1) mask += '0123456789';
        var result = '';
        for (var i = length; i > 0; --i) result += mask[Math.floor(Math.random() * mask.length)];
        return result;
    },
    
    createRoomLink: function( room_id ) {
        return window.location.href;
    },
    
    initPcConfig: function() {
        var pc_config = {
            "rtcpMuxPolicy": "require",
            "bundlePolicy": "max-bundle",
            "iceServers": []
        };
        //TODO: Correctly assign iceServers
        return JSON.stringify(pc_config);
    },
    
    test_ice_servers: [
        {urls:'stun:stun01.sipphone.com'},
        {urls:'stun:stun.ekiga.net'},
        {urls:'stun:stun.fwdnet.net'},
        {urls:'stun:stun.ideasip.com'},
        {urls:'stun:stun.iptel.org'},
        {urls:'stun:stun.rixtelecom.se'},
        {urls:'stun:stun.schlund.de'},
        {urls:'stun:stun.l.google.com:19302'},
        {urls:'stun:stun1.l.google.com:19302'},
        {urls:'stun:stun2.l.google.com:19302'},
        {urls:'stun:stun3.l.google.com:19302'},
        {urls:'stun:stun4.l.google.com:19302'},
        {urls:'stun:stunserver.org'},
        {urls:'stun:stun.softjoys.com'},
        {urls:'stun:stun.voiparound.com'},
        {urls:'stun:stun.voipbuster.com'},
        {urls:'stun:stun.voipstunt.com'},
        {urls:'stun:stun.voxgratia.org'},
        {urls:'stun:stun.xten.com'},
        {
        	urls: 'turn:numb.viagenie.ca',
        	credential: 'muazkh',
        	username: 'webrtc@live.com'
        },
        {
        	urls: 'turn:192.158.29.39:3478?transport=udp',
        	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
        	username: '28224511:1379330808'
        },
        {
        	urls: 'turn:192.158.29.39:3478?transport=tcp',
        	credential: 'JZEOEt2V3Qb0y27GRntt2u2PAYA=',
        	username: '28224511:1379330808'
        }]
}