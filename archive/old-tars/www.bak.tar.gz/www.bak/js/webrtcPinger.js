
/* globals parseJSON */

'use strict';

// A simple pinger to verify connectivity with other clients
var WebRTCPinger = function(dataChannel, clientId) {
    this.channel_ = dataChannel;
    this.clientId_ = clientId;
    
    // Set up pong reply channel
    this.channel_.onmessage = function(event) {
        var message = JSON.parse(event.data);
        if(message.is_ping) {
            console.log("Pinger :: "+this.clientId_+" received ping from "+message.from);
            this.sendPong_(message);
        } else {
            console.log("Pinger :: "+this.clientId_+" received pong from "+message.from+" for "+message.to);
        }
    }.bind(this);
};

WebRTCPinger.prototype.start = function() {
    console.log("Pinger :: Starting WebRTC Pinger");  
    
    // Create pinger interval function
    this.pinger_ = setInterval( function() {
        this.sendPing_();
    }.bind(this), 10000);
};

WebRTCPinger.prototype.sendPing_ = function() {
    if(this.channel_) {
        if(this.channel_.readyState == "open") {
            console.log("Pinger :: "+this.clientId_+" sending ping");
            var data = {
                "is_ping": true,
                "from": this.clientId_
            };
            this.channel_.send(JSON.stringify(data));
        } else {
            console.log("Pinger :: Pinger DataChannel state = "+this.channel_.readyState);
        }
    } else {
        console.log("Pinger :: ERROR: DataChannel not connected. Stopping pinger");
        clearInterval(this.pinger_);
    }
};

WebRTCPinger.prototype.sendPong_ = function(message) {
    if(this.channel_) {
            console.log("Pinger :: "+this.clientId_+" sending pong to "+message.from);
        var data = {
            "is_ping": false,
            "from": this.clientId_,
            "to": message.from
        };
        this.channel_.send(JSON.stringify(data));
    } else {
        console.log("Pinger :: ERROR: DataChannel not connected. Stopping pinger.");  
        clearInterval(this.pinger_);
    }
};
