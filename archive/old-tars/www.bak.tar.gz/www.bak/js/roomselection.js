/*
 *  Copyright (c) 2015 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree.
 */

/* More information about these options at jshint.com/docs/options */

/* globals randomString, Storage, parseJSON */
/* exported RoomSelection */

'use strict';

var RoomSelection = function(roomSelectionDiv, uiConstants, recentRoomsKey, setupCompletedCallback) {
  this.roomSelectionDiv_ = roomSelectionDiv;

  this.setupCompletedCallback_ = setupCompletedCallback;

  this.roomIdInput_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomSelectionInput);
  this.roomIdInputLabel_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomSelectionInputLabel);
  
  this.roomPasswordInput_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomPasswordInput);
  this.roomPasswordInputLabel_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomPasswordInputLabel);
      
  this.roomJoinButton_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomSelectionJoinButton);
  this.roomRandomButton_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomSelectionRandomButton);
  this.roomRecentList_ = this.roomSelectionDiv_.querySelector(
      uiConstants.roomSelectionRecentList);

  
  this.roomIdInput_.value = webchatTools.randomString(8);
  this.roomPasswordInput_.value = webchatTools.randomString(8, 'aA')+webchatTools.randomString(2, '#');
  // Call onRoomIdPasswordInput_ now to validate initial state of input box.
  this.onRoomIdPasswordInput_();

  this.roomIdInputListener_ = this.onRoomIdPasswordInput_.bind(this);
  this.roomIdInput_.addEventListener('input', this.roomIdInputListener_, false);

  this.roomIdKeyupListener_ = this.onRoomIdKeyPress_.bind(this);
  this.roomIdInput_.addEventListener('keyup', this.roomIdKeyupListener_, false);
  
  this.roomPasswordInputListener_ = this.onRoomIdPasswordInput_.bind(this);
  this.roomPasswordInput_.addEventListener('input', this.roomPasswordInputListener_, false);

  this.roomPasswordKeyupListener_ = this.onRoomIdKeyPress_.bind(this);
  this.roomPasswordInput_.addEventListener('keyup', this.roomPasswordKeyupListener_, false);

  this.roomRandomButtonListener_ = this.onRandomButton_.bind(this);
  this.roomRandomButton_.addEventListener(
      'click', this.roomRandomButtonListener_, false);

  this.roomJoinButtonListener_ = this.onJoinButton_.bind(this);
  this.roomJoinButton_.addEventListener(
      'click', this.roomJoinButtonListener_, false);

  // Public callbacks. Keep it sorted.
  this.onRoomSelected = null;
};

RoomSelection.matchRandomRoomPattern = function(input) {
  return input.match(/^\d{9}$/) !== null;
};

RoomSelection.prototype.removeEventListeners = function() {
  console.log("this.onRoomSelected = "+this.onRoomSelected);
  this.roomIdInput_.removeEventListener('input', this.roomIdInputListener_);
  this.roomIdInput_.removeEventListener('keyup', this.roomIdKeyupListener_);
  this.roomPasswordInput_.removeEventListener('input', this.roomPasswordInputListener_);
  this.roomPasswordInput_.removeEventListener('keyup', this.roomPasswordKeyupListener_);
  this.roomRandomButton_.removeEventListener(
      'click', this.roomRandomButtonListener_);
  this.roomJoinButton_.removeEventListener(
      'click', this.roomJoinButtonListener_);
};

RoomSelection.prototype.onRoomIdPasswordInput_ = function() {
  // Validate room id, enable/disable join button.
  // The server currently accepts only the \w character class and
  // hyphen+underscor.
  var re = /^([a-zA-Z0-9-_]+)+$/;
  
  var room = this.roomIdInput_.value;
  var room_valid = room.length >= 5;
  room_valid = room_valid && re.exec(room);
  
  var pword = this.roomPasswordInput_.value;
  var pword_valid = pword.length >= 8;
  pword_valid = pword_valid && re.exec(pword);
  
  if (room_valid && pword_valid) {
    this.roomJoinButton_.disabled = false;
    this.roomIdInput_.classList.remove('invalid');
    this.roomIdInputLabel_.classList.add('hidden');
    this.roomPasswordInput_.classList.remove('invalid');
    this.roomPasswordInputLabel_.classList.add('hidden');
  } else {
    this.roomJoinButton_.disabled = true;
    if(room_valid) {
      this.roomIdInput_.classList.remove('invalid');
      this.roomIdInputLabel_.classList.add('hidden');
    } else {
      this.roomIdInput_.classList.add('invalid');
      this.roomIdInputLabel_.classList.remove('hidden');
    }
    if(pword_valid) {
      this.roomPasswordInput_.classList.remove('invalid');
      this.roomPasswordInputLabel_.classList.add('hidden');
    } else {
      this.roomPasswordInput_.classList.add('invalid');
      this.roomPasswordInputLabel_.classList.remove('hidden');
    }
  }
};

RoomSelection.prototype.onRoomIdKeyPress_ = function(event) {
  if (event.which !== 13 || this.roomJoinButton_.disabled) {
    return;
  }
  this.onJoinButton_();
};

RoomSelection.prototype.onRandomButton_ = function() {
  this.roomIdInput_.value = webchatTools.randomString(8);
  this.roomPasswordInput_.value = webchatTools.randomString(10);
  this.onRoomIdPasswordInput_();
};

RoomSelection.prototype.onJoinButton_ = function() {
  this.loadRoom_(this.roomIdInput_.value, this.roomPasswordInput_.value);
};

RoomSelection.prototype.loadRoom_ = function(roomName, roomPassword) {
  webchatServerless.joinRoom(roomName, roomPassword);
  
  var interval_id = setInterval(function() {
    if (webchatServerless.is_logged_in) {
      appController.hide_($(UI_CONSTANTS.roomSelectionDiv));
      appController.createCall_();
      appController.finishCallSetup_(roomName);
  
      appController.roomSelection_.removeEventListeners();
      appController.roomSelection_ = null;
      if (appController.localStream_) {
        appController.attachLocalStream_();
      }
      
      clearInterval(interval_id);
      console.log("Room selected!");
    }
  }, 1000);
};
