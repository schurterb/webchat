/* globals mergeConstraints, parseJSON, iceCandidateType,
   maybePreferAudioReceiveCodec, maybePreferVideoReceiveCodec,
   maybePreferAudioSendCodec, maybePreferVideoSendCodec,
   maybeSetAudioSendBitRate, maybeSetVideoSendBitRate,
   maybeSetAudioReceiveBitRate, maybeSetVideoSendInitialBitRate,
   maybeSetVideoReceiveBitRate, maybeSetVideoSendInitialBitRate,
   maybeRemoveVideoFec, maybeSetOpusOptions, WebRTCPinger, CustomEvent,
   RTCPeerConnection, RTCIceCandidate, RTCSessionDescription */

/* exported PeerConnection */

'use strict';

var PeerConnection = function(params, startTime) {
  this.params_ = params;
  this.startTime_ = startTime;

  console.log('Creating RTCPeerConnnection with:\n' +
    '  config: \'' + JSON.stringify(params.peerConnectionConfig) + '\';\n' +
    '  constraints: \'' + JSON.stringify(params.peerConnectionConstraints) +
    '\'.');

  this.pc_ = new RTCPeerConnection(params.peerConnectionConfig, params.peerConnectionConstraints);
  this.pc_.onicecandidate = this.onIceCandidate_.bind(this);
  this.pc_.ontrack = this.onRemoteStreamAdded_.bind(this);
  this.pc_.onremovestream = console.log.bind(null, 'Remote stream removed.');
  this.pc_.onsignalingstatechange = this.onSignalingStateChanged_.bind(this);
  this.pc_.oniceconnectionstatechange = this.onIceConnectionStateChanged_.bind(this);
  window.dispatchEvent(new CustomEvent('pccreated', {
    detail: {
      pc: this,
      time: new Date(),
      userId: this.params_.roomId + (this.isInitiator_ ? '-0' : '-1'),
      sessionId: this.params_.roomId
    }
  }));

  this.hasRemoteSdp_ = false;
  this.messageQueue_ = [];
  this.isInitiator_ = false;
  this.started_ = false;
  
  this.onerror = null;
  this.oniceconnectionstatechange = null;
  this.onnewicecandidate = null;
  this.onremotehangup = null;
  this.onremotesdpset = null;
  this.onremotestreamadded = null;
  this.onsignalingmessage = null;
  this.onsignalingstatechange = null;
  
  // Pinger
  this.remotePingers = [];
  this.pc_.ondatachannel = function(event) {
    var pinger = new WebRTCPinger(event.channel, this.params_.clientId);
    pinger.start();
    this.remotePingers.push(pinger);
  }.bind(this); 
  var dataChannel = this.pc_.createDataChannel("PingChannel", { id:42 });
  this.pinger = new WebRTCPinger(dataChannel, this.params_.clientId);
};

// Always set up audio and video, and don't use voice detection
PeerConnection.DEFAULT_SDP_OFFER_OPTIONS_ = {
  offerToReceiveAudio: 1,
  offerToReceiveVideo: 1,
  voiceActivityDetection: false
};

PeerConnection.prototype.addStream = function(stream) {
  if (!this.pc_) {
    return;
  }
  this.pc_.addStream(stream);
};

PeerConnection.prototype.initiateCall = function(offerOptions) {
  if (!this.pc_) {
    return false;
  }

  if (this.started_) {
    return false;
  }

  this.isInitiator_ = true;
  this.started_ = true;
  var constraints = mergeConstraints(
      PeerConnection.DEFAULT_SDP_OFFER_OPTIONS_, offerOptions);
  console.log('Sending offer to peer, with constraints: \n\''+JSON.stringify(constraints)+'\'.');
  this.pc_.createOffer(constraints)
      .then(this.setLocalSdpAndNotify_.bind(this))
      .catch(this.onError_.bind(this, 'createOffer'));

  return true;
};

PeerConnection.prototype.joinCall = function(initialMessages) {
  if (!this.pc_) {
    return false;
  }

  if (this.started_) {
    return false;
  }

  this.isInitiator_ = false;
  this.started_ = true;

  if (initialMessages && initialMessages.length > 0) {
    for (var i = 0, len = initialMessages.length; i < len; i++) {
      this.receiveSignalingMessage(initialMessages[i]);
    }
    return true;
  }
  
  if (this.messageQueue_.length > 0) {
    this.drainMessageQueue_();
  }
  return true;
};

PeerConnection.prototype.receiveSignalingMessage = function(message) {
  var messageObj = parseJSON(message);
  if (!messageObj) {
    console.log("Failed to parse "+message);
    return;
  }
  if ((this.isInitiator_ && messageObj.type === 'answer') ||
      (!this.isInitiator_ && messageObj.type === 'offer')) {
    this.hasRemoteSdp_ = true;
    // Always process offer before candidates.
    this.messageQueue_.unshift(messageObj);
  } else if (messageObj.type === 'candidate') {
    this.messageQueue_.push(messageObj);
  } else if (messageObj.type === 'bye') {
    if (this.onremotehangup) {
      this.onremotehangup();
    }
  }
  this.drainMessageQueue_();
};

PeerConnection.prototype.close = function() {
  if (!this.pc_) {
    return;
  }

  this.pc_.close();
  window.dispatchEvent(new CustomEvent('pcclosed', {
    detail: {
      pc: this,
      time: new Date(),
    }
  }));
  this.pc_ = null;
};

//TODO: Test to see if this is useful
PeerConnection.prototype.getPeerConnectionStates = function() {
  if (!this.pc_) {
    return null;
  }
  return {
    'signalingState': this.pc_.signalingState,
    'iceGatheringState': this.pc_.iceGatheringState,
    'iceConnectionState': this.pc_.iceConnectionState
  };
};

//TODO: Test to see if this is useful
PeerConnection.prototype.getPeerConnectionStats = function(callback) {
  if (!this.pc_) {
    return;
  }
  this.pc_.getStats(null).then(callback);
};

PeerConnection.prototype.createAnswer_ = function() {
  console.log('Sending answer to peer.');
  this.pc_.createAnswer()
      .then(this.setLocalSdpAndNotify_.bind(this))
      .catch(this.onError_.bind(this, 'createAnswer'));
};

PeerConnection.prototype.setLocalSdpAndNotify_ =
    function(sessionDescription) {
      sessionDescription.sdp = maybeSetOpusOptions(sessionDescription.sdp, this.params_);
      sessionDescription.sdp = maybePreferAudioReceiveCodec(sessionDescription.sdp, this.params_);
      sessionDescription.sdp = maybePreferVideoReceiveCodec(sessionDescription.sdp, this.params_);
      sessionDescription.sdp = maybeSetAudioReceiveBitRate(sessionDescription.sdp, this.params_);
      sessionDescription.sdp = maybeSetVideoReceiveBitRate(sessionDescription.sdp, this.params_);
      sessionDescription.sdp = maybeRemoveVideoFec(sessionDescription.sdp, this.params_);
      
      this.pc_.setLocalDescription(sessionDescription)
          .then(console.log.bind(null, 'Set session description success.'))
          .catch(this.onError_.bind(this, 'setLocalDescription'));

      if (this.onsignalingmessage) {
        // To avoid issue with Chrome version of RTCSessionDescription ...
        this.onsignalingmessage({
          sdp: sessionDescription.sdp,
          type: sessionDescription.type
        });
      }
    };

PeerConnection.prototype.setRemoteSdp_ = function(message) {
  message.sdp = maybeSetOpusOptions(message.sdp, this.params_);
  message.sdp = maybePreferAudioSendCodec(message.sdp, this.params_);
  message.sdp = maybePreferVideoSendCodec(message.sdp, this.params_);
  message.sdp = maybeSetAudioSendBitRate(message.sdp, this.params_);
  message.sdp = maybeSetVideoSendBitRate(message.sdp, this.params_);
  message.sdp = maybeSetVideoSendInitialBitRate(message.sdp, this.params_);
  message.sdp = maybeRemoveVideoFec(message.sdp, this.params_);
  
  this.pc_.setRemoteDescription(new RTCSessionDescription(message))
      .then(this.onSetRemoteDescriptionSuccess_.bind(this))
      .catch(this.onError_.bind(this, 'setRemoteDescription'));
};

PeerConnection.prototype.onSetRemoteDescriptionSuccess_ = function() {
  console.log('Set remote session description success. Checking for remote streams.');
  var remoteStreams = this.pc_.getRemoteStreams();
  if (this.onremotesdpset) {
    this.onremotesdpset(remoteStreams.length > 0 && remoteStreams[0].getVideoTracks().length > 0);
  }
};

PeerConnection.prototype.processSignalingMessage_ = function(message) {
  if (message.type === 'offer' && !this.isInitiator_) {
    if (this.pc_.signalingState !== 'stable') {
      console.log('ERROR: remote offer received in unexpected state: ' +
            this.pc_.signalingState);
      return;
    }
    this.setRemoteSdp_(message);
    this.createAnswer_();
  } else if (message.type === 'answer' && this.isInitiator_) {
    if (this.pc_.signalingState !== 'have-local-offer') {
      console.log('ERROR: remote answer received in unexpected state: ' +
            this.pc_.signalingState);
      return;
    }
    this.setRemoteSdp_(message);
  } else if (message.type === 'candidate') {
    var candidate = new RTCIceCandidate({
      sdpMLineIndex: message.label,
      candidate: message.candidate
    });
    this.recordIceCandidate_('Remote', candidate);
    this.pc_.addIceCandidate(candidate)
        .then(console.log.bind(null, 'Remote candidate added successfully.'))
        .catch(this.onError_.bind(this, 'addIceCandidate'));
  } else {
    console.log('WARNING: unexpected message: ' + JSON.stringify(message));
  }
};

// When we receive messages from GAE registration and from the WSS connection,
// we add them to a queue and drain it if conditions are right.
PeerConnection.prototype.drainMessageQueue_ = function() {
  if (!this.pc_ || !this.started_ || !this.hasRemoteSdp_) {
    return;
  }
  for (var i = 0, len = this.messageQueue_.length; i < len; i++) {
    this.processSignalingMessage_(this.messageQueue_[i]);
  }
  this.messageQueue_ = [];
};

PeerConnection.prototype.onIceCandidate_ = function(event) {
  if (event.candidate) {
    if (this.filterIceCandidate_(event.candidate)) {
      var message = {
        type: 'candidate',
        label: event.candidate.sdpMLineIndex,
        id: event.candidate.sdpMid,
        candidate: event.candidate.candidate
      };
      if (this.onsignalingmessage) {
        this.onsignalingmessage(message);
      }
      this.recordIceCandidate_('Local', event.candidate);
    }
  } else {
    console.log('End of candidates.');
  }
};

PeerConnection.prototype.onSignalingStateChanged_ = function() {
  if (!this.pc_) {
    return;
  }
  console.log('Signaling state changed to: ' + this.pc_.signalingState);

  if (this.onsignalingstatechange) {
    this.onsignalingstatechange(this.pc_.signalingState);
  }
};

PeerConnection.prototype.onIceConnectionStateChanged_ = function() {
  if (!this.pc_) {
    return;
  }
  console.log('ICE connection state changed to: ' + this.pc_.iceConnectionState);
  
  if (this.pc_.iceConnectionState === 'completed') {
    console.log('ICE complete time: ' + (window.performance.now() - this.startTime_).toFixed(0) + 'ms.');
  }
  
  if (this.pc_.iceConnectionState == 'connected' && this.pinger) {
    this.pinger.start();
  }

  if (this.oniceconnectionstatechange) {
    this.oniceconnectionstatechange();
  }
};

PeerConnection.prototype.filterIceCandidate_ = function(candidateObj) {
  
  if (candidateObj.candidate.indexOf('tcp') !== -1) {
    return false;
  }

  if (this.params_.peerConnectionConfig.iceTransports === 'relay' && 
      iceCandidateType(candidateObj.candidate) !== 'relay') {
    return false;
  }

  return true;
};

PeerConnection.prototype.recordIceCandidate_ = function(location, candidateObj) {
  if (this.onnewicecandidate) {
    this.onnewicecandidate(location, candidateObj.candidate);
  }
};

PeerConnection.prototype.onRemoteStreamAdded_ = function(event) {
  if (this.onremotestreamadded) {
    this.onremotestreamadded(event.streams[0]);
  }
};

PeerConnection.prototype.onError_ = function(tag, error) {
  console.log(tag+': '+error.toString());
};
