
/* globals navigator, WebchatServerlessChannel, PeerConnection, 
   webchatTools, RTCPeerConnection, webchatServerless */

/* exported Negotiator */

'use strict';

var Negotiator = function(params, channel) {
  this.params_ = params;
  this.channel_ = channel;
  this.channel_.onmessage = this.onRecvSignalingChannelMessage_.bind(this);
  
  this.pcClient_ = null;
  this.peers_ = {};
  this.localStream_ = null;
  this.errorMessageQueue_ = [];
  this.startTime = null;
  
  this.oncallerstarted = null;
  this.onerror = null;
  this.onnewicecandidate = null;
  this.oniceconnectionstatechange = null;
  this.onsignalingstatechange = null;
  this.onlocalstreamadded = null;
  this.onremotestreamadded = null;
  this.onremotehangup = null;
  this.onremotesdpset = null;

  this.getMediaPromise_ = null;
  this.getIceServersPromise_ = null;
  this.requestMediaAndIceServers_();
};

Negotiator.prototype.requestMediaAndIceServers_ = function() {
  this.getMediaPromise_ = this.maybeGetMedia_();
  this.getIceServersPromise_ = this.maybeGetIceServers_();
};

Negotiator.prototype.start = function(roomId) {
  this.connectToRoom_(roomId);
};

Negotiator.prototype.restart = function() {
  // Reinitialize the promises
  this.requestMediaAndIceServers_();
  this.start(this.params_.previousRoomId);
};

Negotiator.prototype.hangup = function(runAsAsync) {
  this.startTime = null;

  if (this.localStream_) {
    if (typeof this.localStream_.getTracks === 'undefined') {
      // Support legacy browsers, like phantomJs we use to run tests.
      this.localStream_.stop();
    } else {
      this.localStream_.getTracks().forEach(function(track) {
        track.stop();
      });
    }
    this.localStream_ = null;
  }

  if (!this.params_.roomId) {
    return;
  }

  if (this.pcClient_) {
    this.pcClient_.close();
    this.pcClient_ = null;
  }
  
  // Send 'leave' to GAE. This must complete before saying BYE to other client.
  // When the other client sees BYE it attempts to post offer and candidates to
  // GAE. GAE needs to know that we're disconnected at that point otherwise
  // it will forward messages to this client instead of storing them.

  // This section of code is executed in both sync and async depending on
  // where it is called from. When the browser is closed, the requests must
  // be executed as sync to finish before the browser closes. When called
  // from pressing the hang up button, the requests are executed async.

  var steps = [];
  steps.push({
    step: function() {
      // Send leave to GAE
      this.channel_.close();
    }.bind(this),
    errorString: 'Error sending /leave:'
  });
  steps.push({
    step: function() {
      // Send bye to the other client.
      this.channel_.send(JSON.stringify({type: 'bye'}));
    }.bind(this),
    errorString: 'Error sending bye:'
  });
  steps.push({
    step: function() {
      // Close signaling channel.
      return this.channel_.close(runAsAsync);
    }.bind(this),
    errorString: 'Error closing signaling channel:'
  });
  steps.push({
    step: function() {
      // Clear params
      this.params_.roomId = null;
      this.params_.clientId = null;
    }.bind(this),
    errorString: 'Error setting params:'
  });

  if (runAsAsync) {
    var errorHandler = function(errorString, error) {
      console.log(errorString + ' ' + error.message);
    };
    var promise = Promise.resolve();
    for (var i = 0; i < steps.length; ++i) {
      promise = promise.then(steps[i].step).catch(
          errorHandler.bind(this, steps[i].errorString));
    }

    return promise;
  }
  // Execute the cleanup steps.
  var executeStep = function(executor, errorString) {
    try {
      executor();
    } catch (ex) {
      console.log(errorString + ' ' + ex);
    }
  };

  for (var j = 0; j < steps.length; ++j) {
    executeStep(steps[j].step, steps[j].errorString);
  }

  if (this.params_.roomId !== null || this.params_.clientId !== null) {
    console.log('ERROR: sync cleanup tasks did not complete successfully.');
  } else {
    console.log('Cleanup completed.');
  }
  return Promise.resolve();
};

Negotiator.prototype.onRemoteHangup = function() {
  this.startTime = null;
  
  // On remote hangup this client becomes the new initiator.
  this.params_.isInitiator = true;

  if (this.pcClient_) {
    this.pcClient_.close();
    this.pcClient_ = null;
  }

  this.startSignaling_();
};

//TODO: Test to see if this is useful
Negotiator.prototype.getPeerConnectionStates = function() {
  if (this.pcClient_) {
    return this.pcClient_.getPeerConnectionStates();
  }
};

//TODO: Test to see if this is useful
Negotiator.prototype.getPeerConnectionStats = function(callback) {
  if (this.pcClient_) {
    this.pcClient_.getPeerConnectionStats(callback);
  }
};

Negotiator.prototype.toggleVideoMute = function() {
  var videoTracks = this.localStream_.getVideoTracks();
  if (videoTracks.length === 0) {
    console.log('No local video available.');
    return;
  }

  console.log('Toggling video mute state.');
  for (var i = 0; i < videoTracks.length; ++i) {
    videoTracks[i].enabled = !videoTracks[i].enabled;
  }
  console.log('Video ' + (videoTracks[0].enabled ? 'unmuted.' : 'muted.'));
};

Negotiator.prototype.toggleAudioMute = function() {
  var audioTracks = this.localStream_.getAudioTracks();
  if (audioTracks.length === 0) {
    console.log('No local audio available.');
    return;
  }

  console.log('Toggling audio mute state.');
  for (var i = 0; i < audioTracks.length; ++i) {
    audioTracks[i].enabled = !audioTracks[i].enabled;
  }
  console.log('Audio ' + (audioTracks[0].enabled ? 'unmuted.' : 'muted.'));
};

Negotiator.prototype.connectToRoom_ = function(roomId) {
  this.params_.roomId = roomId;
  this.params_.roomKey = webchatServerless.room_password;
  var channelPromise = this.channel_.open();
  
  // Asynchronously join the room.
  var joinPromise = this.joinRoom_().then(function(roomParams) {
    
    this.params_.clientId = roomParams.client_id;
    this.params_.roomId = roomParams.room_id;
    this.params_.roomKey = webchatServerless.room_password;
    this.params_.roomLink = roomParams.room_link;
    this.params_.isInitiator = roomParams.is_initiator === 'true';

    this.params_.messages = roomParams.messages;
  }.bind(this)).catch(function(error) {
    this.onError_('Error occured joinging room.  Reason: ' + error.message);
    return Promise.reject(error);
  }.bind(this));
  
  // 1) Open channel and 2) join room
  Promise.all([channelPromise, joinPromise]).then(function() {
    
    // 3) register channel
    Promise.all([this.channel_.register(this.params_.roomId, this.params_.clientId)]).then(function() {
      
      // 4) Get Ice servers and 5) media
      Promise.all([this.getIceServersPromise_, this.getMediaPromise_]).then(function() {
        
        // 6) Finally, start signalling.
        this.startSignaling_();
      }.bind(this)).catch(function(error) {
        this.onError_('Failed to start signaling.  Reason: ' + error.message);
      }.bind(this));
    }.bind(this));
  }.bind(this)).catch(function(error) {
    this.onError_('Error occured while registering channel.  Reason: ' + error.message);
  }.bind(this));
};

// Asynchronously request user media if needed.
Negotiator.prototype.maybeGetMedia_ = function() {
  var needStream = (this.params_.mediaConstraints.audio !== false ||
                    this.params_.mediaConstraints.video !== false);
  var mediaPromise = null;
  if (needStream) {
    var mediaConstraints = this.params_.mediaConstraints;

    mediaPromise = navigator.mediaDevices.getUserMedia(mediaConstraints)
        .catch(function(error) {
          if (error.name !== 'NotFoundError') {
            throw error;
          }
          return navigator.mediaDevices.enumerateDevices()
              .then(function(devices) {
                var cam = devices.find(function(device) {
                  return device.kind === 'videoinput';
                });
                var mic = devices.find(function(device) {
                  return device.kind === 'audioinput';
                });
                var constraints = {
                  video: cam && mediaConstraints.video,
                  audio: mic && mediaConstraints.audio
                };
                return navigator.mediaDevices.getUserMedia(constraints);
              });
        })
        .then(function(stream) {
          console.log('Got access to local media with mediaConstraints:\n' +
          '  \'' + JSON.stringify(mediaConstraints) + '\'');

          this.onUserMediaSuccess_(stream);
        }.bind(this)).catch(function(error) {
          this.onError_('Error getting user media: ' + error.message);
          this.onUserMediaError_(error);
        }.bind(this));
  } else {
    mediaPromise = Promise.resolve();
  }
  return mediaPromise;
};

// Asynchronously request an ICE server if needed.
Negotiator.prototype.maybeGetIceServers_ = function() {
  if ( !this.params_.peerConnectionConfig.iceServers || (this.params_.peerConnectionConfig.iceServers.length === 0)) {
    this.params_.peerConnectionConfig.iceServers = webchatTools.getIceServers(2);
  }
  return Promise.resolve();
};

Negotiator.prototype.onUserMediaSuccess_ = function(stream) {
  this.localStream_ = stream;
  if (this.onlocalstreamadded) {
    this.onlocalstreamadded(stream);
  }
};

Negotiator.prototype.onUserMediaError_ = function(error) {
  var errorMessage = 'Failed to get access to local media. Error name was ' +
      error.name + '. Continuing without sending a stream.';
  this.onError_('getUserMedia error: ' + errorMessage);
  this.errorMessageQueue_.push(error);
  alert(errorMessage);
};

Negotiator.prototype.maybeCreatePcClientAsync_ = function() {
  return new Promise(function(resolve, reject) {
    
    if (this.pcClient_) {
      resolve();
      return;
    }

    if (typeof RTCPeerConnection.generateCertificate === 'function') {
      var certParams = {name: 'ECDSA', namedCurve: 'P-256'};
      RTCPeerConnection.generateCertificate(certParams)
          .then(function(cert) {
            console.log('ECDSA certificate generated successfully.');
            this.params_.peerConnectionConfig.certificates = [cert];
            this.createPcClient_();
            resolve();
          }.bind(this))
          .catch(function(error) {
            console.log('ECDSA certificate generation failed.');
            reject(error);
          });
    } else {
      this.createPcClient_();
      resolve();
    }
  }.bind(this));
};

Negotiator.prototype.getPeerConnection = function( peer ) {
  if(Object.values(this.peers_).indexOf(peer) > -1) {
    return this.peers_[peer];
  } else {
    
    await Promise.all([this.createNewPcClient()]);
    
    
    
  }
}

Negotiator.prototype.createPcClient_ = function() {
  console.log('Creating Peer Client.');
  this.pcClient_ = new PeerConnection(this.params_, this.startTime);
  this.pcClient_.onsignalingmessage = this.sendSignalingMessage_.bind(this);
  this.pcClient_.onremotehangup = this.onremotehangup;
  this.pcClient_.onremotesdpset = this.onremotesdpset;
  this.pcClient_.onremotestreamadded = this.onremotestreamadded;
  this.pcClient_.onsignalingstatechange = this.onsignalingstatechange;
  this.pcClient_.oniceconnectionstatechange = this.oniceconnectionstatechange;
  this.pcClient_.onnewicecandidate = this.onnewicecandidate;
  this.pcClient_.onerror = this.onerror;
  console.log('Peer Client created.');
};

Negotiator.prototype.startSignaling_ = function() {
  console.log('Starting signaling.');
  if (this.params_.isInitiator && this.oncallerstarted) {
    this.oncallerstarted(this.params_.roomId, this.params_.roomId, this.params_.roomLink);
  }

  this.startTime = window.performance.now();

  this.maybeCreatePcClientAsync_()
      .then(function() {
        if (this.localStream_) {
          console.log('Adding local stream.');
          this.pcClient_.addStream(this.localStream_);
        }
        if (this.params_.isInitiator) {
          this.pcClient_.initiateCall(this.params_.offerOptions);
        } else {
          this.pcClient_.joinCall(this.params_.messages);
        }
      }.bind(this))
      .catch(function(e) {
        this.onError_('Cannot create RTCPeerConnection.  Reason: ' + e);
        alert('Cannot create RTCPeerConnection.  Reason: ' + e.message);
      }.bind(this));
};

// Join the room and returns room parameters.
Negotiator.prototype.joinRoom_ = function() {
  return new Promise(async function(resolve, reject) {
    
    if (!this.params_.roomId) {
      reject(Error('Missing room id.'));
    }
    
    var room_id = this.params_.roomId;
    var media_constraints = JSON.stringify(this.params_.mediaConstraints);
    
    var client_id = webchatTools.randomString(8);
    var room_link = webchatTools.createRoomLink(room_id);
    //TODO: Create the room, too!
    var pc_config = webchatTools.initPcConfig();
    
    var fileList = await webchatServerless.listFiles();
    var is_initiator = "true";
    var messages = [];
    if(fileList.length > 0) {
      is_initiator = "false";
      messages = await webchatServerless.getFile(fileList[0]);
      messages = JSON.parse(messages.Body);
    }
    
    var responseObj = {
      "params": {
        "offer_options": "{}", 
        "client_id": client_id, 
        "room_id": room_id, 
        "wss_url": "", 
        "wss_post_url": "", 
        "room_link": room_link,
        "pc_config": pc_config, 
        "pc_constraints": "{\"optional\": []}", 
        "version_info": null,
        "ice_server_transports": "",  
        "ice_server_url": "", 
        "header_message": "", 
        "is_initiator": is_initiator, 
        "messages": messages, 
        "warning_messages": [], 
        "error_messages": [], 
        "is_loopback": "false", 
        "bypass_join_confirmation": "false", 
        "media_constraints": "{\"audio\": false, \"video\": false}", 
        "include_loopback_js": ""
      }, 
      "result": "SUCCESS"
    }
    resolve(responseObj.params);
    
  }.bind(this));
};

Negotiator.prototype.onRecvSignalingChannelMessage_ = function(msg) {
  this.maybeCreatePcClientAsync_(msg.peer).then(this.pcClient_.receiveSignalingMessage(msg.data));
};

Negotiator.prototype.sendSignalingMessage_ = async function(message) {
  var msgString = JSON.stringify(message);
  console.log('C->GAE: ' + msgString);
  await this.channel_.send(msgString);
};

Negotiator.prototype.onError_ = function(message) {
  if (this.onerror) {
    this.onerror(message);
  }
};
