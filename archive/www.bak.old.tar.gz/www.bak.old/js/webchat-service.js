
/* globals PeerConnection, RoomSelection, $, webchatServerless,
           queryStringToDictionary, Negotiator, UI_CONSTANTS */

/* exported WebchatService */

var WebchatService = function(params, channel) {
  this.params_ = params;
  this.channel_ = channel;
  this.connectedPeers_ = [];
  this.dataChannelMessageHandlers_ = [];
  
  this.roomLink_ = '';
  this.localStream_ = null;
  this.remoteVideoResetTimer_ = null;
  this.roomId_ = null;
  this.roomPassword = null;
  
  this.loadUrlParams_();
  
  this.onError_ = null;
  this.onCallerStarted_ = null;
  this.onRemoteHangup_ = null;
  this.onRemoteSdpSet_ = null;
  this.onRemoteStreamAdded_ = null;
  this.onLocalStreamAdded_ = null;
}

WebchatService.prototype.start = function(roomId, roomPassword) {
  
  console.log(" ### Room Id = "+roomId);
  this.params_.roomId = roomId;
  console.log(" *** JSON.stringify(this.params_) = "+JSON.stringify(this.params_));
  this.negotiator_ = new Negotiator(this.params_, this.channel_);

  if(this.params_.errorMessages) {
    var roomErrors = this.params_.errorMessages;
    if (roomErrors && roomErrors.length > 0) {
      for (var i = 0; i < roomErrors.length; ++i) {
        console.log("Room Error: "+roomErrors[i]);
      }
      return;
    }
  }
  
  if(this.params_.warningMessages) {
    var roomWarnings = this.params_.warningMessages;
    if (roomWarnings && roomWarnings.length > 0) {
      for (var j = 0; j < roomWarnings.length; ++j) {
        console.log("Room Warning: "+roomWarnings[i]);
      }
    }
  }
  
  this.negotiator_.onremotehangup = this.onRemoteHangup_;
  this.negotiator_.onremotesdpset = this.onRemoteSdpSet_;
  this.negotiator_.onremotestreamadded = this.onRemoteStreamAdded_;
  this.negotiator_.onlocalstreamadded = this.onLocalStreamAdded_;
  
  this.negotiator_.onerror = this.onError_;
  this.negotiator_.oncallerstarted = this.onCallerStarted_;

  this.negotiator_.onsignalingstatechange = function(event) {
    if(event)
      console.log(" ## ## onsignalingstatechange event :: "+JSON.stringify(event));
    else
      console.log(" ## ## onsignalingstatechange event :: no data");
  }
  this.negotiator_.oniceconnectionstatechange = function(event) {
    if(event)
      console.log(" ## ## oniceconnectionstatechange event :: "+JSON.stringify(event));
    else
      console.log(" ## ## oniceconnectionstatechange event :: no data");
  }
  this.negotiator_.onnewicecandidate = function(location, candidate) {
    console.log(" ## ## onnewicecandidate event :: location = "+JSON.stringify(location)+", candidate = "+JSON.stringify(candidate));
  }
  
  this.negotiator_.start(this.params_.roomId);
  
  //TODO: Add logic to process data channel messages from peers.
  
  //TODO: Add logic to handler new peers.
};

// Sends a message to the specified peers, if connected.
// If no peers are specified, then it sends the message to all peers.
WebchatService.prototype.sendDataChannelMessage = function(message, peers = []) {
  if( !peers || (peers.length == 0)) {
    peers = this.connectedPeers_;
  }
  
  //TODO: Send message
}

// Adds a handler to process data channel messages.
WebchatService.prototype.addDataChannelMessageHandler = function(handler) {
  if(handler && !this.dataChannelMessageHandlers_.includes(handler)) {
    this.dataChannelMessageHandlers_.push(handler);
  }
}

WebchatService.prototype.loadUrlParams_ = function() {
  /* eslint-disable dot-notation */
  var DEFAULT_VIDEO_CODEC = 'VP9';
  var urlParams = queryStringToDictionary(window.location.search);
  this.params_.audioSendBitrate = urlParams['asbr'];
  this.params_.audioSendCodec = urlParams['asc'];
  this.params_.audioRecvBitrate = urlParams['arbr'];
  this.params_.audioRecvCodec = urlParams['arc'];
  this.params_.opusMaxPbr = urlParams['opusmaxpbr'];
  this.params_.opusFec = urlParams['opusfec'];
  this.params_.opusDtx = urlParams['opusdtx'];
  this.params_.opusStereo = urlParams['stereo'];
  this.params_.videoSendBitrate = urlParams['vsbr'];
  this.params_.videoSendInitialBitrate = urlParams['vsibr'];
  this.params_.videoSendCodec = urlParams['vsc'];
  this.params_.videoRecvBitrate = urlParams['vrbr'];
  this.params_.videoRecvCodec = urlParams['vrc'] || DEFAULT_VIDEO_CODEC;
  this.params_.videoFec = urlParams['videofec'];
  /* eslint-enable dot-notation */
};
